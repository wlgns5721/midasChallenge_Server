package midas;
import javax.swing.JPanel;

public class ClassExplorer extends JPanel{

}
